cd lib/t
prove --exec '/usr/bin/env perl -I../lib' tests.t
