#!/bin/bash
cd data/IntPred/
wget "http://bioinf.org.uk/intpred/models/IntPred.model.gz" && gzip -d IntPred.model.gz
